package com.gflights.ui;

import java.awt.DisplayMode;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.gflights.model.BookingModel;
import com.gflights.model.USER;
import com.gflights.repository.BookingRepository;
import com.gflights.util.MainMenuUtil;
import com.gflights.util.MenuUtil;

public class MainApplication {
	
	public static USER loggedUser=new USER();
	
	public static void displayMainMenu() {
	       int choice2 = MainMenuUtil.displayMainMenu();
	        if(choice2 == 1) {
	        	System.out.println("Enter details for booking:::");
	        	System.out.println("Source: "); 
	        	String source=new Scanner(System.in).nextLine();
	        	System.out.println("Destination: ");
	        	String dest=new Scanner(System.in).nextLine();
	        	System.out.println("Ticket Class: ");
	        	String ticketClass=new Scanner(System.in).nextLine();
	        	System.out.println("No Of Passengers: "); 
	        	Integer noOfPass=Integer.valueOf(new Scanner(System.in).nextLine());
	        	System.out.println(" Is it a Round Trip ? YES/NO: ");
	        	boolean isRoundTrip=new Scanner(System.in).nextLine().equalsIgnoreCase("YES") ? true : false;
	        	
	            Optional<BookingModel> bookingModel = Optional.ofNullable(MenuUtil.bookFlights(new BookingModel(source, dest, ticketClass,noOfPass , isRoundTrip, loggedUser)));

	            if (bookingModel.isPresent()) {
		            System.out.println("Below ticket has been booked for current user:::");
		            System.out.println(bookingModel);
				}
	            
	        } else if(choice2 == 2) {
	        	System.out.println("Displaying all booking in the flight::: ");
	        	List<BookingModel> list=MenuUtil.displayAllBookingsForFlight();
	        	list.stream().forEach(booking -> System.out.println(booking));
	        } else if(choice2 == 3) {
	        	System.out.println("Displaying all booking for the current user::: ");
	        	List<BookingModel> list=MenuUtil.displayAllBookingsForUser();
	        	list.stream().forEach(booking -> System.out.println(booking));
	        } else if(choice2 == 4) {
	        	System.out.println("Please enter booking ID for searching::: ");
	        	Optional<BookingModel> booking=Optional.ofNullable(MenuUtil.searchBookingByBookingId(new Scanner(System.in).nextLine()));
	        	if(booking.isPresent())
	        	System.out.println(booking);
	        	else System.out.println("No bookings found for given id");
	        } else if(choice2 == 5) {
	        	System.out.println("Enter details for updating:::");
	        	System.out.println("Booking ID: "); 
	        	String bookingId=new Scanner(System.in).nextLine();

	        	if(!BookingRepository.bookingsMap.values().stream().
	        			filter(b -> b.getBookingId().equals(bookingId)).
	        			collect(Collectors.toList()).isEmpty()) {
	        		
	        	
	        	if(!BookingRepository.bookingsMap.values().stream().
	        			filter(b ->b.getUser().getUserId().equals(loggedUser.getUserId())).
	        			filter(b -> b.getBookingId().equals(bookingId)).
	        			collect(Collectors.toList()).isEmpty()) {
	        	System.out.println("Source: "); 
	        	String source=new Scanner(System.in).nextLine();
	        	System.out.println("Destination: ");
	        	String dest=new Scanner(System.in).nextLine();
	        	System.out.println("Ticket Class: ");
	        	String ticketClass=new Scanner(System.in).nextLine();
	        	System.out.println("No Of Passengers: "); 
	        	Integer noOfPass=Integer.valueOf(new Scanner(System.in).nextLine());
	        	System.out.println(" Is it a Round Trip ? YES/NO: ");
	        	boolean isRoundTrip=new Scanner(System.in).nextLine().equalsIgnoreCase("YES") ? true : false;
	        	
	            Optional<BookingModel> bookingModel = Optional.ofNullable(MenuUtil.updateBookingByBookingId(bookingId,new BookingModel(source, dest, ticketClass,noOfPass , isRoundTrip,loggedUser)));

	            if (bookingModel.isPresent()) {
		            System.out.println("Below ticket has been updated for current user:::");
		            System.out.println(bookingModel);
				}else {
					System.out.println("Something went wrong while updating please try again");
				}
	        	}else {
	        		System.out.println("Please enter a booking id that belongs to current user..");
	        	}
	        	}else {
	        		System.out.println("Please enter an existing booking id");
	        	}
	        	
	        } else if(choice2 == 6) {
	        	System.out.println("Please enter booking ID for deleting::: ");
	        	System.out.println("Booking ID: ");
	        	String bookingId=new Scanner(System.in).nextLine();

	        	if(!BookingRepository.bookingsMap.values().stream().
	        			filter(b -> b.getBookingId().equals(bookingId)).
	        			collect(Collectors.toList()).isEmpty()) {
	      
	        	if(!BookingRepository.bookingsMap.values().stream().
	        			filter(b ->b.getUser().getUserId().equals(loggedUser.getUserId())).
	        			filter(b -> b.getBookingId().equals(bookingId)).
	        			collect(Collectors.toList()).isEmpty()) {

	        	if(MenuUtil.deleteBookingByBookingId(bookingId)) {
	        		System.out.println("Booking record deleted");
	        	}else {
	        		System.out.println("Something went wrong while deleting please try again");
	        	}
	        	}else {
	        		System.out.println("Please enter a booking id that belongs to current user.");
	        	} 
	        	}else {
	        		System.out.println("Please enter an existing bookingId id");
	        	}
	        } else if(choice2 == 7) {
	        	System.out.println("Logging Out.... ");
	            loggedUser.setUserId(null);loggedUser.setUserName(null);
	           
	        	System.out.println("Logged Out. Please loging again to continue");
	        	main(null);
	        } else if(choice2 == 8) {
	        	System.out.println("Exiting Application.... ");
	        	try {
					BookingRepository.connection.close();
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
	        	System.exit(0);
		        } else if(choice2 == 9) {
		        	System.out.println("Fetching booking usng booking id ");
		        	System.out.println("Please enter booking ID::: ");
		        	System.out.println("Booking ID: ");
		        	String bookingId=new Scanner(System.in).nextLine();
		        	BookingRepository.getBookingDetailsWithProc(bookingId);
		        	try {
						BookingRepository.connection.close();
					} catch (SQLException e) {
						System.out.println(e.getMessage());
					}
		        	System.exit(0);
			        } 
	            else {
	        	System.out.println("Please Enter a valid option");
	        }
	        
	        displayMainMenu();
	}
    public static void main( String[] args ) {   
        int choice1=MainMenuUtil.enterUser();
        if(choice1==1) {
        	System.out.print ("Enter user id::: ");System.out.println();
        	Integer userId=Integer.valueOf(new Scanner(System.in).nextLine());
        	System.out.print ("Enter user password::: ");System.out.println();
        	String password=new Scanner(System.in).nextLine();
        	if(MenuUtil.loginUser(userId,password)) {
        		System.out.println("User Loggedin");
        		System.out.println("Initialized cache with all booking details... ");
        		BookingRepository.loadAllBookings();

        	displayMainMenu();
        	}else {
        		System.out.println("Please provide valid user id/password");
        		main(args);
        	}
        }else if(choice1==2) {
        	System.out.println("Registering User");
        	System.out.print ("Enter user name::: ");System.out.println();
        	String name=new Scanner(System.in).nextLine();
        	System.out.print ("Enter password::: ");System.out.println();
        	String password=new Scanner(System.in).nextLine();
        	if(MenuUtil.registerUser(name,password)) {
        		System.out.print("Registered User with user id: "+loggedUser.getUserId()+" and ");
        		System.out.println("user name: "+loggedUser.getUserName()+" ");
        		System.out.println("Bookings will be done for above user:::");
        	displayMainMenu();
        	}else {
        		System.out.println("Registration failed please try again");
        		main(args);
        	}

        } else if(choice1 == 3) {
        	System.out.println("Exiting Application.... ");
        	try {
				BookingRepository.connection.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
        	System.exit(0);
	        }
        else {
        	System.out.println("Please Enter a valid option");
        }
        
            
        }
  
}