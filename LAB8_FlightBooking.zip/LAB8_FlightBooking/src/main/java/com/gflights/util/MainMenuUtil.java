package com.gflights.util;

import java.util.Scanner;

import com.gflights.repository.BookingRepository;

public class MainMenuUtil {
    public static int displayMainMenu(){
        System.out.println("Please choose one option from the menu");
        System.out.println("1. Book Flights");
        System.out.println("2. Display all bookings in Flight");
        System.out.println("9. Display booking using booking id");
        System.out.println("3. Display all bookings for current user");
        System.out.println("4. Search bookings by bookingId");
        System.out.println("5. Update bookings");
        System.out.println("6. Delete a booking");
        System.out.println("7. Logout");
        System.out.println("8. Exit");
        return Integer.valueOf(new Scanner(System.in).nextLine());
        
    }

	public static int enterUser() {
		System.out.println("Welcome to GFlights...");
		System.out.println("Please Login Or Register to continue:::");
		System.out.println("1. Login");
		System.out.println("2. Register");
		System.out.println("3. Exit");
		return Integer.valueOf(new Scanner(System.in).nextLine());
		
	}
    
    
    
    
}