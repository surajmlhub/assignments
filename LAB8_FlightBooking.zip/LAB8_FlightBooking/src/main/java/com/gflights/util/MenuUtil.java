package com.gflights.util;

import java.util.ArrayList;
import java.util.List;

import com.gflights.model.BookingModel;
import com.gflights.repository.BookingRepository;

public class MenuUtil {
	
	public static boolean loginUser(Integer userId, String password) {
		return BookingRepository.login(userId,password);
	}
	public static boolean registerUser(String name, String password) {
		return BookingRepository.register(name, password);
	}
        public static BookingModel bookFlights(BookingModel model) {
        if(BookingRepository.addBooking(model));
        return model;
    }
        
        public static List<BookingModel> displayAllBookingsForFlight() {
        return BookingRepository.displayAllBookingsInFlight();
        
    }
        public static List<BookingModel> displayAllBookingsForUser() {
        	 return BookingRepository.displayAllBookingsForCurrentUser();
        }
        public static BookingModel searchBookingByBookingId(String bookingId) {
        	return BookingRepository.searchBookingById(bookingId);
    }
        
        public static BookingModel updateBookingByBookingId(String bookingId, BookingModel model) {
        	if(BookingRepository.updateBooking(bookingId,model));
            return model;
        }
        public static boolean deleteBookingByBookingId(String bookingId) {
        	return BookingRepository.deleteBookingByBookingId(bookingId);
        }


}