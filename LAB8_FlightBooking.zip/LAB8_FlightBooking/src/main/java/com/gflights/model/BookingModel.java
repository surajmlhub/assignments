package com.gflights.model;

public class BookingModel {
    private String bookingId;
    private String source;
    private String dest;
    private String ticketClass;
    private int noOfPassengers;
    private boolean isRoundTrip;

    private USER user;

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDest() {
		return dest;
	}

	public void setDest(String dest) {
		this.dest = dest;
	}

	public String getTicketClass() {
		return ticketClass;
	}

	public void setTicketClass(String ticketClass) {
		this.ticketClass = ticketClass;
	}

	public int getNoOfPassengers() {
		return noOfPassengers;
	}

	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}

	public boolean isRoundTrip() {
		return isRoundTrip;
	}

	public void setRoundTrip(boolean isRoundTrip) {
		this.isRoundTrip = isRoundTrip;
	}

	public USER getUser() {
		return user;
	}

	public void setUser(USER user) {
		this.user = user;
	}

	public BookingModel() {
		
	}
	public BookingModel(String source, String dest, String ticketClass, int noOfPassengers,
			boolean isRoundTrip, USER user) {
		super();
		this.source = source;
		this.dest = dest;
		this.ticketClass = ticketClass;
		this.noOfPassengers = noOfPassengers;
		this.isRoundTrip = isRoundTrip;
		this.user = user;
	}

	@Override
	public String toString() {
		return "BookingModel [bookingId=" + bookingId + ", source=" + source + ", dest=" + dest + ", ticketClass="
				+ ticketClass + ", noOfPassengers=" + noOfPassengers + ", isRoundTrip=" + isRoundTrip + ", user=" + user
				+ "]";
	}
    
    
    
}