package com.gflights.repository;

import com.gflights.model.BookingModel;
import com.gflights.model.USER;
import com.gflights.ui.MainApplication;
import com.mysql.cj.jdbc.CallableStatement;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.x.protobuf.MysqlxPrepare.Prepare;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class BookingRepository {
	public static Connection connection;
	public static Map<String,BookingModel> bookingsMap=new HashMap<>();
	public static Map<String,USER> userssMap=new HashMap<>();
	static {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila", "root", "Admin@123");
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		}
	
	public static boolean login(Integer userId, String password) {
		try {
			PreparedStatement statement=connection.prepareStatement("SELECT * FROM sakila.users where id=? and password=?;");
			statement.setInt(1, userId);
			statement.setString(2, password);
			ResultSet resultset=statement.executeQuery();
			while(resultset.next()) {
				MainApplication.loggedUser.setUserId(resultset.getInt(1)+"");
				MainApplication.loggedUser.setUserName(resultset.getString(2));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return MainApplication.loggedUser.getUserId()!=null;
	}
	
	public static boolean register(String name, String password) {
		try {
			PreparedStatement statement=connection.prepareStatement("INSERT INTO sakila.users (name, password) VALUES (?, ?);",Statement.RETURN_GENERATED_KEYS);
			statement.setString(1, name);
			statement.setString(2, password);
			int result=statement.executeUpdate();
	
			if(result>=1) {
				ResultSet set=statement.getGeneratedKeys();
				if (set.next()) {
					MainApplication.loggedUser.setUserId(set.getInt(1)+"");
					MainApplication.loggedUser.setUserName(name);
				}
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return MainApplication.loggedUser.getUserId()!=null;
	}
        
    public static void loadAllBookings() {
    	try {
			PreparedStatement statement=connection.prepareStatement("SELECT * FROM sakila.bookings;");
			ResultSet resultset=statement.executeQuery();
			while(resultset.next()) {
			    loadAllUsers();
				BookingModel booking=new BookingModel();
				booking.setBookingId(resultset.getInt(1)+"");
				booking.setSource(resultset.getString(2));
				booking.setDest(resultset.getString(3));
				booking.setNoOfPassengers(resultset.getInt(4));
				booking.setTicketClass(resultset.getString(5));
				booking.setRoundTrip(resultset.getString(6).compareToIgnoreCase("YES")==0?true:false);
				booking.setUser(userssMap.get(resultset.getInt(7)+""));
				bookingsMap.put(booking.getBookingId(), booking);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
		
	private static void loadAllUsers() {
		try {
		PreparedStatement statement2=connection.prepareStatement("SELECT * FROM sakila.users;");
		ResultSet resultset2=statement2.executeQuery();
		while(resultset2.next()) {
			USER user=new USER();
			user.setUserId(resultset2.getInt(1)+"");
			user.setUserName(resultset2.getString(2));
			userssMap.put(user.getUserId(), user);
		}
		}catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}


	public static boolean addBooking(BookingModel bookingModel) {
    	try {
			PreparedStatement statement=connection.prepareStatement("INSERT INTO sakila.bookings (source, destination, NoOfPassengers, ticketClass, roundTrip, user_id) VALUES (?,?, ?, ?,?, ?);\r\n" + 
					"",Statement.RETURN_GENERATED_KEYS);
			statement.setString(1, bookingModel.getSource());
			statement.setString(2, bookingModel.getDest());
			statement.setInt(3, bookingModel.getNoOfPassengers());
			statement.setString(4, bookingModel.getTicketClass());
			statement.setString(5, bookingModel.isRoundTrip()?"YES":"NO");
			statement.setInt(6, Integer.valueOf(bookingModel.getUser().getUserId()));
			int result=statement.executeUpdate();
			if (result>=1) {
				ResultSet set=statement.getGeneratedKeys();
				if(set.next())
				bookingModel.setBookingId(set.getInt(1)+"");
				
				bookingsMap.put(bookingModel.getBookingId(), bookingModel);
			} else {
				bookingModel=null;
			}
			return ((int) result>=1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return false;
    }

	public static List<BookingModel> displayAllBookingsInFlight() {
		return bookingsMap.values().stream().collect(Collectors.toList());
	}

	public static List<BookingModel> displayAllBookingsForCurrentUser() {
		return bookingsMap.values().stream().filter(b ->b.getUser().getUserId().equals(MainApplication.loggedUser.getUserId())).collect(Collectors.toList());
		
	}
	
	public static BookingModel searchBookingById(String bookingId) {
		if(!bookingsMap.values().stream().filter(b ->b.getBookingId().equals(bookingId)).collect(Collectors.toList()).isEmpty())
		return bookingsMap.values().stream().filter(b ->b.getBookingId().equals(bookingId)).collect(Collectors.toList()).get(0);
		
		else return null;
	}

	public static boolean updateBooking(String bookingId, BookingModel bookingModel) {
	   	try {
				PreparedStatement statement=connection.prepareStatement("UPDATE sakila.bookings SET source = ?, destination = ?, NoOfPassengers = ?, ticketClass = ?, roundTrip = ? WHERE (id = ?);");
				statement.setString(1, bookingModel.getSource());
				statement.setString(2, bookingModel.getDest());
				statement.setInt(3, bookingModel.getNoOfPassengers());
				statement.setString(4, bookingModel.getTicketClass());
				statement.setString(5, bookingModel.isRoundTrip()?"YES":"NO");
				statement.setString(6, bookingId);
				
				int result=statement.executeUpdate();
				if (result>=1) {
					bookingModel.setBookingId(bookingId);
					bookingsMap.replace(bookingModel.getBookingId(), bookingModel);
				} else {
					bookingModel=null;
				}
				return ((int) result>=1);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			return false;
	    }

	public static boolean deleteBookingByBookingId(String bookingId) {
		try {
		PreparedStatement statement2=connection.prepareStatement("delete FROM sakila.bookings where id=?;");
		statement2.setInt(1, Integer.valueOf(bookingId));
		int result=statement2.executeUpdate();
		if(result>=1)
			bookingsMap.remove(bookingId);
		return result>=1;
		}catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return false;

	}
	
	public static void getBookingDetailsWithProc(String bookingId) {
		try {
	    //GetBookingDetails
		java.sql.CallableStatement statement=connection.prepareCall("{call GetBookingDetails(?)}");
		statement.setString(1, bookingId);
		ResultSet result=statement.executeQuery();
		if(result.next())
			System.out.println(result.getString(1)+" "+result.getString(2)+" "+result.getString(3)+" "+result.getString(4)+" "+result.getString(5)+" "+result.getString(6)+" "+result.getString(7));
		}catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}
	
}